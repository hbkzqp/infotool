﻿"use strict"
function arrayFlat(nestedArray)
{
    //judge whether the parameter is array
    if(!isArray(nestedArray))
    {
        return "The requirement Parameter is Integer Array";
    }
    //result and recursion parameter
    var resultArray = new Array();
    //make recursion to process
    return arrayTransfer(nestedArray, resultArray);
}
//recursive process the data, once element is array, recursion, once it is int, add.
function arrayTransfer(nestedArray,resultArray)
{
    for(var i =0;i<nestedArray.length;i++)
    {
        var currentItem = nestedArray[i];
        //array, recursion
        if (isArray(currentItem))
        {
            arrayTransfer(currentItem, resultArray);
        }

        //int, add to result
        else
        {
            if(!isIntegers(currentItem))
            {
                return "The requirement Parameter is Integer Array";
            }
            resultArray.push(currentItem);
        }
    }
    return resultArray;
}
//judge whether it is an array
function isArray(testarray)
{
    if (testarray instanceof Array ||
    (!(testarray instanceof Object) &&
        (Object.prototype.toString.call((testarray)) == '[object Array]') ||
        typeof testarray.length == 'number' &&
        typeof testarray.splice != 'undefined' &&
        typeof testarray.propertyIsEnumerable != 'undefined' &&
        !testarray.propertyIsEnumerable('splice'))) {
        return true;
    }
    return false;
}
//judge integer
function isIntegers(testint)
{
    var intRegex = /[0-9]+/;
    if(intRegex.test(testint))
    {
        return true;
    }
    return false;
}