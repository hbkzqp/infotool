﻿"use strict"

function htmlNestCheck(htmlToBeChecked) {
    if (typeof htmlToBeChecked != 'string') {
        return "The requirement Parameter is string"
    }
    //regular expression for any element, start element and end element
    var elementReg = /<[^(<>)]+>/;
    var startELementReg = /<[^(/<>)]+>/;
    var endElementReg = /<\/[^(/<>)]+>/;
    //stack to store start element
    var startElementList = new Array();
    //iterater variable, which gets element
    var elements = htmlToBeChecked.match(elementReg);
    while (elements != null)
    {

        var element = elements[0];
        //once it is start element, add into stack
        if (startELementReg.test(element)) {
            startElementList.push(element);
        }
        //or it is end element, make comparation with the last start element
        else if (endElementReg.test(element)) {
            var endName = getName(element);
            //if start element lis is empty,means this end element is redundant return
            if (startElementList.length == 0) {
                return buildError(null, endName, 1);
            }
            //or pop one and make content comparation
            var startElement = startElementList.pop();
            var startName = getName(startElement);
            //if they are not the same, return error
            if (startName != endName) {
                return buildError(startName, endName, 0);
            }
        }
        //replace the checked element with some unrelated characters
        htmlToBeChecked = htmlToBeChecked.replace(elementReg, buildReplaceStr(element));
        //go on iteration
        elements = htmlToBeChecked.match(elementReg);
    }
    //if start elements are more than end elements, return error
    var length = startElementList.length

    if (length != 0) {

        return buildError(getName(startElementList[length - 1]), null, 2);
    }
    // no erroe
    return "Correctly tagged paragraph";
}
//build error return message
function buildError(start,end,model)
{
    if (model == 0)
    {
        return "Expected </" + start + "> found </" + end + ">";
    }
    if (model == 1) {
        return "Expected # found </" + end + ">";
    }
    if (model == 2) {
        return "Expected </" + start + "> found #";
    }
    else
        return "Correctly tagged paragraph";
}
// build unrelated words to replace check element
function buildReplaceStr(element)
{
    var resultStr = "";
    for(var i =0;i<element.length;i++)
    {
        resultStr = resultStr + "i";
    }
    return resultStr;
}
//get name from html element
function getName(nameElement)
{
    var elementNameReg = /[A-Za-z]+/;
    return nameElement.match(elementNameReg)[0];
}
