﻿function isEqual(testcase, result) {
    return testcase == result;
}
test('isEqual()', function () {
    var arrayFlatTestCases = buildArrayFlatCase();
    var arrayHtmlNestCases = buildHtmlNestCase();
    for (var i = 0; i < 4; i++)
    {
        var currentcase = arrayFlatTestCases[0][i];
        var result = arrayFlat(currentcase);
        for(var j = 0;j<result.length;j++)
        {
            ok(isEqual(result[j], arrayFlatTestCases[0][6+i][j], 'number is equal'));
        }
    }
    for (var i = 4; i < 6; i++)
    {
        var currentcase = arrayFlatTestCases[0][i];
        var currentcase = arrayFlatTestCases[0][i];
        var result = arrayFlat(currentcase);
        
        ok(isEqual("The requirement Parameter is Integer Array", result, 'wrong hint is equal'));
    }


    for (var i = 0; i < 7; i++)
    {
        var currentcase = arrayHtmlNestCases[0][i];
        var result = htmlNestCheck(currentcase);
        console.log(result);
        ok(isEqual(arrayHtmlNestCases[0][7+i], result, ' '));
    }
});


function buildArrayFlatCase() {
    
    var testCases = new Array();
    //case 1 , correct
    var testcase1 = [1, 2, 3, 4];
    var testresult1 = [1, 2, 3, 4];
    //case 2 , one nested array
    var testcase2 = [1, [1, 2], 3, 4];
    var testresult2 = [1, 1, 2, 3, 4];
    //case 3 , one larger nested array
    var testcase3 = [1, [1, 2, 3], 3, 4];
    var testresult3 = [1, 1, 2, 3, 3, 4];
    //case 4 , one double nested array
    var testcase4 = [1, [1, [1, 2, 3], 3], 3, 4];
    var testresult4 = [1, 1, 1, 2, 3, 3, 3, 4];
    //case 5 , wrong case, a string
    var testcase5 = "aaa";
    var testresult5 = "The requirement Parameter is Integer Array";
    //case 6 , wrong case, a string inside
    var testcase6 = [1, [1, [1, 2, 3], 3], 3, "aaa"];
    var testresult6 = "The requirement Parameter is Integer Array";
    var caseArray = new Array();
    caseArray.push(testcase1);
    caseArray.push(testcase2);
    caseArray.push(testcase3);
    caseArray.push(testcase4);
    caseArray.push(testcase5);
    caseArray.push(testcase6);
    var resultArray = new Array();
    caseArray.push(testresult1);
    caseArray.push(testresult2);
    caseArray.push(testresult3);
    caseArray.push(testresult4);
    caseArray.push(testresult5);
    caseArray.push(testresult6);
    testCases.push(caseArray);
    testCases.push(resultArray);
    return testCases;
}

function buildHtmlNestCase() {
    var testCases = new Array();
    //case 1 , correct
    var testcase1 = "<html><head><title>RefactorMe Tests</title></head><body><div id=\"qunit\"></div></body></html>";
    var testresult1 = "Correctly tagged paragraph"
    //case 2 , no <title> but exists</title>
    var testcase2 = "<html><head>RefactorMe Tests</title></head><body><div id=\"qunit\"></div></body></html>";//no <title>
    var testresult2 = "Expected </head> found </title>";
    //case 3 , no </div> but exists<title>
    var testcase3 = "<html><head><title>RefactorMe Tests</title></head><body><div id=\"qunit\"></body></html>";//no </div>
    var testresult3 = "Expected </div> found </body>";
    //case 4 , a <img/>element
    var testcase4 = "<html><head><title>RefactorMe Tests<img/></title></head><body><div id=\"qunit\"></div></body></html>";//<img/>
    var testresult4 = "Correctly tagged paragraph";
    //case 5 , only a <html>
    var testcase5 = "<html>";//only<html>
    var testresult5 = "Expected </html> found #";
    //case 6 , wrong case, an int
    var testcase6 = 2;//wrong parameter
    var testresult6 = "The requirement Parameter is string";
    //case 7 , only a </html>
    var testcase7 = "</html>";//no <div/>
    var testresult7 = "Expected # found </html>";
    var caseArray = new Array();
    caseArray.push(testcase1);
    caseArray.push(testcase2);
    caseArray.push(testcase3);
    caseArray.push(testcase4);
    caseArray.push(testcase5);
    caseArray.push(testcase6);
    caseArray.push(testcase7);
    var resultArray = new Array();
    caseArray.push(testresult1);
    caseArray.push(testresult2);
    caseArray.push(testresult3);
    caseArray.push(testresult4);
    caseArray.push(testresult5);
    caseArray.push(testresult6);
    caseArray.push(testresult7);
    testCases.push(caseArray);
    testCases.push(resultArray);
    return testCases;
}